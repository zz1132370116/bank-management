create
    definer = root@`%` procedure transfer_record_test()
BEGIN
	#Routine body goes here...
	DECLARE i INT;
	SET i=0;
	WHILE i<10000 DO
		INSERT INTO transfer_record VALUES (null,'12345678901234567890123456789012',100,SYSDATE(),0,1,'1234567890123456789','1234567890123456789');
	END WHILE;
END;

