create
    definer = root@`%` procedure proc_initData()
BEGIN
    DECLARE i INT DEFAULT 1;
    WHILE i<=1000000 DO
        INSERT INTO transfer_record  VALUES (DEFAULT, UUID(),100,'2018-01-01',0,1,'6217052401532964852','6214488523568569423', '2018-01-01','2018-01-01');
        SET i = i+1;
    END WHILE;
END;

